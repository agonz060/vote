<?php
	// Contains form notices
	$notices = (
		"CEE" => "Comments may be submitted to the chair prior to the department meeting if the faculty member will not be able to attend the meeting and would like the comments brought up at the meeting for discussion.",
		"ECE" => "Anonymous or absentee comments will be raised at the meeting at the Chair's discretion. This is in addition to the above statement i.e. Note: Comments may be submitted.... :)",
		"BOTH" => "Comments may be submitted to the chair prior to the department meeting if the faculty member will not be able to attend the meeting and would like the comments brought up at the meeting for discussion."
	);