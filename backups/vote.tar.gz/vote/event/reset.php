<?php
	# requires
	require_once '../includes/connDB.php';
	require_once '../admin/mailer/autoload.php';

	if($_SERVER["REQUEST_METHOD"] == "POST") {
		// var_dump($_POST);
		$email = cleanInput($_POST['email']);

		if(strlen($email) > 0) {
			$selectStmt = "SELECT email WHERE email='$email'";
			if($result = mysqli_query($conn, $selectStmt)) {
				if($row = mysqli_fetch_row()) {
					echo 'valid email';
				} else {
					echo 'invalid email';
				}
			} else {
				echo json_encode()
			}
		}
	}

	function cleanInput($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}